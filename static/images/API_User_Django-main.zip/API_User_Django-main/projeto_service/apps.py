from django.apps import AppConfig


class ProjetoServiceConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'projeto_service'
