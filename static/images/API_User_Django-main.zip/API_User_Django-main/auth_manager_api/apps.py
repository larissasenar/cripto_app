from django.apps import AppConfig


class AuthManagerApiConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'auth_manager_api'
