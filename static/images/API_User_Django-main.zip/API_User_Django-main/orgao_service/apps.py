from django.apps import AppConfig


class OrgaoServiceConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'orgao_service'
